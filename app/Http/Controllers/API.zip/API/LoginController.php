<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\API\BaseController;
use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Task;
use App\Http\Resources\UserResource;
use Illuminate\Support\Facades\Auth;

class LoginController extends BaseController
{
    public function login(Request $request)
    {
        $user = User::where('email', $request->email)->first();
        if(empty($request->email)){
            return $this->sendError('Empty.', ['error'=>'Please Enter Email']);
        }

        if (!$user) {
            return $this->sendError('Not Found.', ['error'=>'Invalid Email']);
        }

        if(Auth::attempt(['email' => $request->email, 'password' => $request->password])){
            $user = Auth::user();
            
            $success['user'] = new UserResource($user);
            $success['token'] =  $user->createToken('MyApp')->plainTextToken;
            
            $today_assigned_tasks = Task::where('employee_id', $user->id)->whereDate('date', date('Y-m-d'))->where('status', 0)->count();
            $today_completed_tasks = Task::where('employee_id', $user->id)->whereDate('date', date('Y-m-d'))->where('status', 1)->count();
            
            $completed_percent = 0;
            if($today_assigned_tasks > 0){
                $completed_percent = number_format($today_completed_tasks/$today_assigned_tasks*100);
            }
            
            $success['today_completed_percent'] = $completed_percent;
            $success['today_assigned_tasks'] = $today_assigned_tasks;
            $success['today_completed_tasks'] = $today_completed_tasks;
            
            $complement_message = '';
            if ($today_assigned_tasks>0 && $completed_percent < 60) {
                $complement_message = 'You can do it! Keep pushing forward!';
            } else if ($completed_percent >= 60 && $completed_percent <= 80) {
                $complement_message = 'You are making progress! Keep going!';
            } else if ($completed_percent > 80 && $completed_percent <= 90) {
                $complement_message = 'Almost there! Keep it going!';
            } else if ($completed_percent > 90 && $completed_percent < 100) {
                $complement_message = "You're doing great! Just a little more to go!";
            } else if ($completed_percent == 100) {
                $complement_message = 'Hurrah! You have completed the task.';
            }else{
                $complement_message = 'Yet not assigned any task.';
            }
            
            $success['complement_message'] = $complement_message;
            
            $success['all_time_completed_tasks'] = Task::where('employee_id', $user->id)->where('status', 1)->count();
            $success['all_time_unfinished_tasks'] = Task::where('employee_id', $user->id)->where('status', '!=', 1)->count();

            return $this->sendResponse($success, 'User login successfully.');
        }
        else{
            return $this->sendError('Unauthorised.', ['error'=>'Unauthorised']);
        }
    }
    
    public function forgotPassword(Request $request){
        $validator = Validator::make($request->all(), [
            'email' => 'required',
        ]);

        if($validator->fails()){
            return $this->sendError('Validation Error.', $validator->errors());
        }

        $user = User::where('email', $request->email)->first();
        if(!empty($user)){
            try{
                do{
                    $verify_token = mt_rand(1000, 9999);
                }while(User::where('verify_token', $verify_token)->first());

                $user->verify_token = $verify_token;
                $user->update();

                $body = "Hello ".$user->name.  "<br /> <br />".
                        "You are receiving this email because we recieved a password reset request for your account. <br /><br />".
                        "Your Password Reset Token: <b>". $verify_token."</b><br /><br />".
                        "If you did not request a password reset, no further action is required.<br /><br />";

                $mailData = [
                    'title' => 'Password Reset',
                    'body' => $body
                ];

                \Mail::to($request->email)->send(new Email($mailData));

                return $this->sendResponse(null, 'We have sent you token for reset password in your email.');
            } catch (\Exception $e) {
                DB::rollback();
                return $e->getMessage();
            }
        }else{
            return $this->sendError('Account not found.', null);
        }
    }
    
    public function verifyToken(Request $request){
        $validator = Validator::make($request->all(), [
            'verify_token' => 'required',
        ]);

        if($validator->fails()){
            return $this->sendError('Validation Error.', $validator->errors());
        }

        $user = User::where('verify_token', $request->verify_token)->first();
        if($user){
            $success['verify_token'] = $request->verify_token;
            return $this->sendResponse($success, 'You may choose new password.');
        }else{
            return $this->sendError('Unauthorized Access', null);
        }
    }

    public function changePassword(Request $request){
        $validator = Validator::make($request->all(), [
            'password' => 'required|min:6|same:confirm-password',
        ]);

        if($validator->fails()){
            return $this->sendError('Validation Error.', $validator->errors());
        }

        $user = User::where('verify_token', $request->verify_token)->first();
        if($user){
            $user->password = Hash::make($request->password);
            $user->verify_token = null;
            $user->update();

            return $this->sendResponse(null, 'You have changed password successfully.');
        }else{
            return $this->sendError('Unauthorized Access', null);
        }
    }
}
