<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\API\BaseController;
use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Task;
use App\Models\TaskDetail;
use App\Models\TaskPicture;
use DB;
use App\Http\Resources\UserResource;
use App\Http\Resources\TaskResource;
use App\Http\Resources\TaskDetailResource;

class TaskController extends BaseController
{
    public function getUserTasks(Request $request){
        if($request->bearerToken() == ""){
            return $this->sendError('Unauthorized Access', null);
        }

        $userToken = DB::table('personal_access_tokens')->where('id', $request->bearerToken())->first();

        if(empty($userToken)){
            return $this->sendError('Unauthorized Access', null);
        }else{
            $success['user'] = User::where('id', $userToken->tokenable_id)->first();
            
            $success['total_tasks'] = Task::where('employee_id', $userToken->tokenable_id)->where('status', '!=', 2)->count();
            $tasks = Task::where('employee_id', $userToken->tokenable_id)->where('status', '!=', 2)->get();
            $user_tasks = [];
            foreach($tasks as $task){
                $status = 'Pending';
                if($task->status==1){
                    $status = 'Completed';    
                }else{
                    $status = 'Cancelled';    
                }
                
                $user_tasks[date('l, d M', strtotime($task->date))][$task->hasFacility->name][] = [
                    'room_name' => $task->hasRoom->name,    
                    'user_name' => $task->hasEmployee->first_name.' '.$task->hasEmployee->last_name,    
                    'status' => $status,    
                ];
            }
            
            $success['user_tasks'] = $user_tasks;
            
            return $this->sendResponse($success, 'All Your Tasks Report.');
        }
    }
    
    public function getTaskServices(Request $request){
        if($request->bearerToken() == ""){
            return $this->sendError('Unauthorized Access', null);
        }

        $userToken = DB::table('personal_access_tokens')->where('id', $request->bearerToken())->first();

        if(empty($userToken)){
            return $this->sendError('Unauthorized Access', null);
        }else{
            $user = User::where('id', $userToken->tokenable_id)->first();
            $task = Task::where('facility_id', $request->facility_id)->where('room_id', $request->room_id)->where('employee_id', $user->id)->first();
            $success['task'] = new TaskResource($task);
            
            $task_details = TaskDetail::where('task_id', $task->id)->get();
            $task_sevices = [];
            foreach($task_details as $task_detail){
                if($task_detail->status==0){
                    $status = 'Pending';    
                }else if($task_detail->status==1){
                    $status = 'Completed';
                }else{
                    $status = 'Cancelled';
                }
                
                $task_sevices[$task_detail->hasParentService->name][] = [
                    'parent_service_id' => $task_detail->hasParentService->id,    
                    'sub_service_id' => $task_detail->hasSubService->id,    
                    'sub_service_name' => $task_detail->hasSubService->name,    
                    'status' => $status,    
                    'is_checked' => $task_detail->status,    
                ];
            }
            
            $success['task_services'] = $task_sevices;
            
            return $this->sendResponse($success, 'All Your Tasks Report.');
        }
    }
    
    public function storeTaskServices(Request $request){
        if($request->bearerToken() == ""){
            return $this->sendError('Unauthorized Access', null);
        }
        if($request->facility_id == ""){
            return $this->sendError('Facility is required', null);
        }
        if($request->room_id == ""){
            return $this->sendError('Room is required', null);
        }
        
        if($request->parent_services == ""){
            return $this->sendError('Select at least one service to save.', null);
        }

        $userToken = DB::table('personal_access_tokens')->where('id', $request->bearerToken())->first();

        if(empty($userToken)){
            return $this->sendError('Unauthorized Access', null);
        }else{
            $user = User::where('id', $userToken->tokenable_id)->first();
            $task = Task::where('facility_id', $request->facility_id)->where('room_id', $request->room_id)->where('employee_id', $user->id)->first();
            
            $total_task_sub_services = 0;
            foreach($request->parent_services as $parent_service_id=>$sub_services){
                foreach($sub_services as $sub_service_id){
                    $total_task_sub_services++;
                    $task_detail = TaskDetail::where('task_id', $task->id)->where('parent_service_id', $parent_service_id)->where('sub_service_id', $sub_service_id)->first();
                    if(!empty($task_detail)){
                        $task_detail->status = 1;
                        $task_detail->save();
                    }
                }
            }
            
            $is_complete_task = 0;
            if($total_task_sub_services==count($task->hasTaskDetails)){
                $is_complete_task = 1;
            }
            
            $task->extra_hours = $request->extra_hours;
            $task->comment = $task->comment.' User: '.$request->comment;
            $task->status = $is_complete_task;
            $task->save();
            
            if ($request->hasFile('pictures')) {
                $images = $request->file('pictures');
    
                foreach ($images as $image) {
                    $imageName = time() . '_' . $image->getClientOriginalName();
                    $image->move(public_path('admin/assets/img/task_pictures'), $imageName);
                    
                    TaskPicture::create([
                        'task_id' => $task->id,
                        'picture' => $imageName,
                    ]);
                }
            }
            
            return $this->sendResponse(null, 'You have saved your tasks.');
        }
    }
}
